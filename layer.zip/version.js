console.log(require('@opentelemetry/core').VERSION);
